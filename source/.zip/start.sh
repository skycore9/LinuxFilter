insmod ./source/TTCN_LinuxFilter.ko
./config/ConfigFilter load
./config/ConfigFilter user
./config/ConfigFilter appconfig
./config/ConfigFilter policy
./user/WriteDB
